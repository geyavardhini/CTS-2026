# Exercise 2 
