# Exercise 1 
