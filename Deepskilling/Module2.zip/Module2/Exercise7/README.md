# Exercise 7 
