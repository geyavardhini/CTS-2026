# Exercise 3 
