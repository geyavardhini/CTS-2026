# Exercise 6 
