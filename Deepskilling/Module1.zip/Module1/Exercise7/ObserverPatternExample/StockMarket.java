// StockMarket.java

import java.util.ArrayList;
import java.util.List;

// Concrete Subject
public class StockMarket implements Stock {

    private List<Observer> observers = new ArrayList<>();

    private String stockName;
    private double stockPrice;

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {

        for (Observer observer : observers) {
            observer.update(stockName, stockPrice);
        }

    }

    // Update stock price
    public void setStock(String stockName, double stockPrice) {

        this.stockName = stockName;
        this.stockPrice = stockPrice;

        System.out.println("\nStock Updated");
        System.out.println("---------------------------");
        System.out.println("Stock : " + stockName);
        System.out.println("Price : ₹" + stockPrice);

        notifyObservers();
    }
}